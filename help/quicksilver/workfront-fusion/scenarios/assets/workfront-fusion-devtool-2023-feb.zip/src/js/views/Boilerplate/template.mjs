export default `
<section>
	<p>This is a boilerplate</p>
</section>
`;
