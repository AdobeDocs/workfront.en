export default `
<section class="col px-0">
	<div class="content-box">
		<div id="moduleListSearchBar">
			<input type="text" class="pl-2" id="moduleSearch" placeholder="Name or ID of the module">
		</div>
		<div id="moduleList">
			<ul id="moduleListItems" class="list-group m-0 no-border-radius">
				<li class="my-auto text-center font-weight-bold text-secondary lead">No modules available</li>
			</ul>
		</div>
	</div>
</section>
<section class="col px-0 bc-center">
	<div class="content-box">
		<div id="cycleList">
			<ul id="cycleListItems" class="list-group m-0 no-border-radius">
				<li class="my-auto text-center font-weight-bold text-secondary lead">No module selected</li>
			</ul>
		</div>
	</div>
</section>
<section class="col-6 px-0 bc-right">
	<div class="content-box">
		<div id="eventList">
			<ul id="eventListItems" class="list-group m-0 no-border-radius">
				<li class="my-auto text-center font-weight-bold text-secondary lead">No operation selected</li>
			</ul>
		</div>
	</div>
</section>
`;
