export default {
	icon: 'far fa-link',
	name: 'swapConnection',
	label: 'Swap Connection',
	description: `
		The Tool takes the connection from the selected module and sets the same
		connection to all modules of the same app in the scenario.`,
	theme: '#EEEEEE',
	modifier: true,
	input: [
		{
			name: 'sourceModule',
			label: 'Source Module',
			type: 'select',
			options: 'rpc://listModules',
			help: 'Source module to copy the connection from.',
			mappable: true,
			required: true
		}
	],
	steps: [
		{
			type: 'javascript',
			code: `
			Inspector.instance._surface.find(Surface.Module)
				.filter(m => m.package.name === Inspector.seek(parameters.sourceModule).package.name)
				.forEach(m => m.parameters.__IMTCONN__ = Inspector.seek(parameters.sourceModule).parameters.__IMTCONN__);
			`
		}
	],
	rpcs: [
		{
			name: 'listModules',
			steps: [
				{
					type: 'javascript',
					code: `
						return Inspector.instance._surface.find(Surface.Module).map(m => {return{label:\`\${m.config.label} (\${m.__id})\`,value: m.__id}})
					`,
					response: {
						output: '{{result}}'
					}
				}
			]
		}
	]
};
