/**
 * Scenario Debugger
 * label, icon, sourcePage, callback
 */
chrome.devtools.panels.create('Workfront Fusion', null, 'src/html/index.html', () => { });
